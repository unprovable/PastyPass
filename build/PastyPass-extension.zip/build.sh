#!/bin/sh

zip -r -FS ./build/PastyPass-extension.zip * -x *.git* -x ./build/*
