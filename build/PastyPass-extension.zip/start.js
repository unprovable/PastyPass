document.addEventListener('DOMContentLoaded', function () {
    PastyPass();
});